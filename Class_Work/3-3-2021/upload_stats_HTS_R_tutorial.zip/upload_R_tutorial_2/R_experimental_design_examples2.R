# Demo of model formulae in R

###### Example 1: two sample t-test

# log expression data example e.g. from a qPCR of a single gene
expr_example = read.table(file="expr_example.tsv",sep="\t",header=T)

# show first few lines of data to check
head(expr_example)
View(expr_example)  # show in a spreadsheet-like interface
str(expr_example)  # show types of each variable in data.frame
summary(expr_example)

# fit a linear model using lm(): this simple model formula is for a two-sample t-test.
# anova() prints out details about the model fit, in particular the p-value 
anova(lm(response~tissue_type, data=expr_example))

# In R we could also use this simpler syntax for the simple case of two-sample t-test, which itself calls lm()
# t.test(response~tissue_type, data=expr_example, var.equal=T)

###### Example 2: interaction example

# read the dataset into a data.frame
blood.pressure = read.table(file="Blood_pressure.tsv",header = T)

# str gives details of the data.frame
str(blood.pressure)

# Here the model formula is more complex and includes the interaction term
anova(lm(Blood_pressure ~ Age * Dosage, data=blood.pressure))

# Linear models are implemented in terms of linear algebra (matrices)
# model.matrix() gives the design matric which captures the details of the model formula as a matrix
# (we don't need this here- just printing it for interest)
model.matrix(Blood_pressure ~ Age * Dosage, data=blood.pressure)

# Show an interaction plot of this experiment
interaction.plot(ordered(blood.pressure$Age),blood.pressure$Dosage,blood.pressure$Blood_pressure)

###### Example 3: regression example

library("ISwR")

# regression
plot(cystfibr$height,cystfibr$pemax)
abline(lm(pemax~height, data=cystfibr))

summary.lm(lm(pemax~height, data=cystfibr))

Design_matrix <- model.matrix(pemax~height, data=cystfibr)
Y <- cystfibr$pemax

# do least squares fit using linear algebraic formulation
beta <- solve(t(Design_matrix) %*% Design_matrix) %*% t(Design_matrix) %*% Y

# compare with two-sample t-test example from earlier, but treated
#(incorrectly) as a regression problem
stripchart(response~tissue_type, data=expr_example, vertical=T,jitter=0.2)

expr_example2 = expr_example
expr_example2$tissue_type = as.numeric(expr_example2$tissue_type) # don't do this in practice!
plot(expr_example2$tissue_type,expr_example2$response)
abline(lm(response~tissue_type, data=expr_example2))
# note that the slope of the line is difference of means, as the x-axis has a fixed width of 1
summary.lm(lm(response~tissue_type, data=expr_example2))

# compare with difference of means
m <- tapply(expr_example$response,expr_example$tissue_type,mean)
m[2]-m[1]

########## Example 4: multiple testing & FDR example

# install the needed packages the first time
if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("qvalue", version = "3.8")

#if (!requireNamespace("BiocManager", quietly = TRUE))
#  install.packages("BiocManager")
#BiocManager::install("genefilter", version = "3.8")

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("multtest", version = "3.8")


################### FDR multiple testing example ###################
#library("genefilter")  # genefilter is a very simple package giving rowttests()
library("multtest")  # functions for FDR estimation
library("qvalue")  # function for FDR estimation using Storer method

# simulation of a dataset with no differentially expressed genes
load(file ="exprset_null.RData" )
# (exprset_null gives the log expression data for all units
d_null <- NULL
for (i in 1:nrow(exprset_null)) {
  d_null[i] <- summary.lm(lm(exprset_null[i,]~exprset_null_mol.biol))$coefficients[2,4]
  #    d_null[i] <- t.test(exprset_null[i,1:5], exprset_null[i,6:10],var.equal = T)$p.value
}
hist(d_null, breaks=3000, ylim=c(0,50))

# simulation of a dataset with 50 of 20000 differentially expressed genes
load(file ="exprset_sig.RData" )
d_sig <- NULL
for (i in 1:nrow(exprset_sig)) {
  d_sig[i] <- summary.lm(lm(exprset_sig[i,]~exprset_sig_mol.biol))$coefficients[2,4]
  #  d_sig[i] <- t.test(exprset_sig[i,1:5], exprset_sig[i,6:10],var.equal = T)$p.value
}
hist(d_sig, breaks=3000, ylim=c(0,50))

# get adjusted p-values for null simulation
mt <- mt.rawp2adjp(d_null, proc=c("Bonferroni","Holm","BH"))
q.storey <- qvalue(d_null)$qvalues
d_null_fdr <- data.frame(mt$adjp[order(mt$index),], q.storey)
head(d_null_fdr) #[1:3,]

# count how many genes have adjusted p-value below fixed values
apply(d_null_fdr, 2, function(x) sum(x < 0.05))
apply(d_null_fdr, 2, function(x) sum(x < 0.1))
apply(d_null_fdr, 2, function(x) sum(x < 0.2))

# get adjusted p-values for simulation with 50 differentially expressed genes (first 50 genes are differentially expressed)
mt <- mt.rawp2adjp(d_sig, proc=c("Bonferroni","Holm","BH"))
q.storey <- qvalue(d_sig)$qvalues
d_sig_fdr <- data.frame(mt$adjp[order(mt$index),], q.storey)
head(d_sig_fdr)

apply(d_sig_fdr, 2, function(x) sum(x < 0.05))
apply(d_sig_fdr, 2, function(x) sum(x < 0.1))
apply(d_sig_fdr, 2, function(x) sum(x < 0.2))

# As this is a simulation, we know which genes are true positives (in this simulation it is the first 50 genes, but in practice we would not know this), so here we show how many true positives there were:
apply(d_sig_fdr[1:50,], 2, function(x) sum(x < 0.2))

#####