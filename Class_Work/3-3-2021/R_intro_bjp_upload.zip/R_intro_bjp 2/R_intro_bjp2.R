

demo(graphics)

################ vector ################
# define the vector
my_vector<- c(1,5,10, 7, 2) 
my_vector [c(1,3,5)]
my_vector[1:4]
my_vector[4:1]

# step

#Figure out at least two ways of making R print your vector in the other direction 
my_vector[c(5,4,3,2,1)]
my_vector[c(5:1)]
rev(my_vector)

#analyzing vectors
big_vector<-(1:10000) 
length(big_vector)
sum(big_vector)
mean(big_vector) 

sample(big_vector, 3) 
ls()

big_vector2<-big_vector +10 
min(big_vector) 
max(big_vector) 
min(big_vector2) 
max(big_vector2) 

# plot vectors
dat<-rnorm (100) #draw 100 random, normal distributed data points 
plot(dat)
plot(dat,type="l")
hist(dat)
hist(dat,breaks=25)

################ data.frame ################
# Reading data.frame from a text file
my.data<-read.table("flowers.txt", header=T)
dim(my.data)
colnames(my.data)
head(my.data) 
str(my.data)

my.data$Sepal.Length

# data types in R

# a character (string) vector
v <- c("a", "b", "c", "b", "a")
str(v)

# convert to a vector of factors
v <- as.factor(v) 
str(v)

# plot data.frame data

# plot single continuous variable- histogram
hist(my.data$Sepal.Length)
# plot single categorical variable- bar plot
plot(my.data$Species)
# continuous versus continuous - scatter plot
plot(my.data$Sepal.Length, my.data$Sepal.Width)
# categorical versus continuous - box plots
plot(my.data$Species, my.data$Sepal.Width)
# categorical versus continuous - strip charts
stripchart(my.data$Sepal.Width ~ my.data$Species, vertical=TRUE, method="jitter")

################ matrix ################
m <- matrix(c(2, 10, 5, 8,7,4), nrow=2, byrow=TRUE) 
m
cbind(m, c(9,7))
m
cbind(m, c(9,7))
rbind(m, c(0,0,1))

m[2,3]
m[,3]

################## R programming #######################
#define it
my_function<- function(x) {
  return(x^2 + x + 1)
}
# run it
my_function(10)
my_function(5)


#Arguments
my_function<- function(y=5,x=10){
  sum(y:x)
}
my_function()
my_function(5,10)
my_function(5,11)

#loop
for(i in 1:5){
  print(i)
}

x<-50:60 # just to have something to try on
# iterating through the values in x
for(i in x){ 
  # i is now the first, second…value   from x 
  print (sqrt(i))
}

# iterating through the indices of x
for(i in 1:length(x)){ 
  # i is now 1,2,3…to the size of x
  print (sqrt( x[i] )) # right!
}

# missing data
my.data<-read.table("flowers.txt", header=T)
head(my.data)

mean(my.data$Sepal.Length)
mean(my.data$Sepal.Length, na.rm=TRUE)

my.data <- complete.cases(my.data)  # remove rows with NA (if data MCAR)

#---------------------------------------------------------
# larger R examples

################## Sampling distribution and CLT #######################

par(mfrow=c(1,3) )  # show plots next to each other
sampling_dist <- NULL # set to an empty vector
# rlnorm(n) generates a random sample of size n from a lognormal distribution

# first show distribution of data
for (i in 1:10000) { sampling_dist[i] <- rlnorm(1) }; 
hist(sampling_dist, xlim=c(-3,9),breaks=100)

# sampling distribution of mean
for (i in 1:10000) { sampling_dist[i] <- mean(rlnorm(10)) }; 
hist(sampling_dist, xlim=c(-3,9),breaks=50)

for (i in 1:10000) { sampling_dist[i] <- mean(rlnorm(100)) }
hist(sampling_dist, xlim=c(-3,9))
par(mfrow=c(1,1) )

# standard error of the mean (SEM) is defined as standard deviation of the sampling distribution of the mean
sd(sampling_dist)

# we can estimate SEM from a single sample by dividing by sqrt(n)
sd(rlnorm(100))/sqrt(100)



#### barplot: Calculate CI for women and men, and plot mean + CI using barplot. #####
install.packages("gplots")
library(gplots)

n1= 10
m1 = 75.3
sd1 = 12

n2 = 9
m2 = 70.3
sd2 = 14

sem1 = sd1/sqrt(n1)
sem2 = sd2/sqrt(n2)

CI1 = sem1 * 1.96   # 2 is a close approximation
CI2 = sem2 * 1.96 

pulse_mean = cbind(women=m1,men=m2)
pulse_ci = cbind(women=CI1,men=CI2)
mp <- barplot2(pulse_mean,width = 0.25,beside= T, col =c("lightblue","grey"),ylim= c(0,100),plot.ci = TRUE, ci.l =  pulse_mean - pulse_ci, ci.u = pulse_mean + pulse_ci)
















